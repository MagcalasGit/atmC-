﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class PayBillsReceipt : Form
    {
        private string selectedCard;
        private double paymentAmount;
        private string selectedCompany;
        private string selectedCompanyElectric;
        private double savingsAmount;
        public PayBillsReceipt(string selectedCompanyElectric, string selectedCompany, string selectedCard, double paymentAmount, double savingsAmount)
        {
            InitializeComponent();
            this.selectedCard = selectedCard;
            this.paymentAmount = paymentAmount;
            this.selectedCompany = selectedCompany;
            this.selectedCompanyElectric = selectedCompanyElectric;
            this.savingsAmount = savingsAmount;
        }

        private void PayBillsReceipt_Load(object sender, EventArgs e)
        {
            creditCardLabel.Text = selectedCompanyElectric;
            creditCardLabel.Text = selectedCompany;
            creditCardLabel.Text = selectedCard;
            lblAccNum.Text = AccountInfo.accountNumber;
            lblAmountAdded.Text = AccountInfo.savingsAmount.ToString("F2");
            lblCurrentBalMin.Text = paymentAmount.ToString("F2");
        }

        private void lblAccNum_Click(object sender, EventArgs e)
        {

        }

        private void lblCurrentBalAdd_Click(object sender, EventArgs e)
        {

        }

        private void creditCardLabel_Click(object sender, EventArgs e)
        {

        }

        private void lblAmountAdded_Click(object sender, EventArgs e)
        {

        }

        private void proceedBtn_Click(object sender, EventArgs e)
        {
            MainPage backtoMain = new MainPage();
            this.Hide();
            backtoMain.Show();
        }
    }
}
