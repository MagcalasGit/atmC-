﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace atmsystem
{
    internal class AccountInfo
    {
        public static double savingsAmount = 100000.00;
        public static double chequeAmount = 100000.00;
        public static string accountNumber = "0000";
    }
}
