﻿namespace atmsystem
{
    partial class PayBillsReceipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PayBillsReceipt));
            proceedBtn = new Guna.UI2.WinForms.Guna2Button();
            lblCurrentBalMin = new Label();
            lblAmountAdded = new Label();
            lblAccNum = new Label();
            creditCardLabel = new Label();
            SuspendLayout();
            // 
            // proceedBtn
            // 
            proceedBtn.BackColor = Color.Transparent;
            proceedBtn.BorderColor = Color.DarkSlateGray;
            proceedBtn.BorderRadius = 15;
            proceedBtn.BorderThickness = 2;
            proceedBtn.CustomizableEdges = customizableEdges1;
            proceedBtn.DisabledState.BorderColor = Color.DarkGray;
            proceedBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            proceedBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            proceedBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            proceedBtn.FillColor = Color.Teal;
            proceedBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            proceedBtn.ForeColor = Color.White;
            proceedBtn.Location = new Point(377, 295);
            proceedBtn.Name = "proceedBtn";
            proceedBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            proceedBtn.Size = new Size(294, 39);
            proceedBtn.TabIndex = 18;
            proceedBtn.Text = "Proceed to Merchant";
            proceedBtn.Click += proceedBtn_Click;
            // 
            // lblCurrentBalMin
            // 
            lblCurrentBalMin.AutoSize = true;
            lblCurrentBalMin.BackColor = Color.Transparent;
            lblCurrentBalMin.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            lblCurrentBalMin.ForeColor = Color.DarkSlateGray;
            lblCurrentBalMin.Location = new Point(537, 176);
            lblCurrentBalMin.Name = "lblCurrentBalMin";
            lblCurrentBalMin.Size = new Size(31, 21);
            lblCurrentBalMin.TabIndex = 27;
            lblCurrentBalMin.Text = "---";
            lblCurrentBalMin.Click += lblCurrentBalAdd_Click;
            // 
            // lblAmountAdded
            // 
            lblAmountAdded.AutoSize = true;
            lblAmountAdded.BackColor = Color.Transparent;
            lblAmountAdded.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            lblAmountAdded.ForeColor = Color.DarkSlateGray;
            lblAmountAdded.Location = new Point(536, 215);
            lblAmountAdded.Name = "lblAmountAdded";
            lblAmountAdded.Size = new Size(31, 21);
            lblAmountAdded.TabIndex = 26;
            lblAmountAdded.Text = "---";
            lblAmountAdded.Click += lblAmountAdded_Click;
            // 
            // lblAccNum
            // 
            lblAccNum.AutoSize = true;
            lblAccNum.BackColor = Color.Transparent;
            lblAccNum.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            lblAccNum.ForeColor = Color.DarkSlateGray;
            lblAccNum.Location = new Point(537, 137);
            lblAccNum.Name = "lblAccNum";
            lblAccNum.Size = new Size(31, 21);
            lblAccNum.TabIndex = 25;
            lblAccNum.Text = "---";
            lblAccNum.Click += lblAccNum_Click;
            // 
            // creditCardLabel
            // 
            creditCardLabel.AutoSize = true;
            creditCardLabel.BackColor = Color.Transparent;
            creditCardLabel.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold);
            creditCardLabel.ForeColor = Color.DarkSlateGray;
            creditCardLabel.Location = new Point(536, 254);
            creditCardLabel.Name = "creditCardLabel";
            creditCardLabel.Size = new Size(31, 21);
            creditCardLabel.TabIndex = 28;
            creditCardLabel.Text = "---";
            creditCardLabel.Click += creditCardLabel_Click;
            // 
            // PayBillsReceipt
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(983, 386);
            Controls.Add(creditCardLabel);
            Controls.Add(lblCurrentBalMin);
            Controls.Add(lblAmountAdded);
            Controls.Add(lblAccNum);
            Controls.Add(proceedBtn);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Name = "PayBillsReceipt";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "PayBillsReceipt";
            Load += PayBillsReceipt_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button proceedBtn;
        private Label lblCurrentBalMin;
        private Label lblAmountAdded;
        private Label lblAccNum;
        private Label creditCardLabel;
    }
}