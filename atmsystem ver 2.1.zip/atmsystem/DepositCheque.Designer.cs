﻿namespace atmsystem
{
    partial class DepositCheque
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DepositCheque));
            CancelBtn = new Guna.UI2.WinForms.Guna2Button();
            confirmBtn = new Guna.UI2.WinForms.Guna2Button();
            label1 = new Label();
            txtDepositCheq = new Guna.UI2.WinForms.Guna2TextBox();
            SuspendLayout();
            // 
            // CancelBtn
            // 
            CancelBtn.BackColor = Color.Transparent;
            CancelBtn.BorderColor = Color.DarkSlateGray;
            CancelBtn.BorderRadius = 15;
            CancelBtn.BorderThickness = 2;
            CancelBtn.CustomizableEdges = customizableEdges1;
            CancelBtn.DisabledState.BorderColor = Color.DarkGray;
            CancelBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            CancelBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            CancelBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            CancelBtn.FillColor = Color.Teal;
            CancelBtn.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CancelBtn.ForeColor = Color.White;
            CancelBtn.Location = new Point(801, 448);
            CancelBtn.Margin = new Padding(3, 4, 3, 4);
            CancelBtn.Name = "CancelBtn";
            CancelBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            CancelBtn.Size = new Size(161, 60);
            CancelBtn.TabIndex = 19;
            CancelBtn.Text = "Cancel";
            CancelBtn.Click += CancelBtn_Click;
            // 
            // confirmBtn
            // 
            confirmBtn.BackColor = Color.Transparent;
            confirmBtn.BorderColor = Color.DarkSlateGray;
            confirmBtn.BorderRadius = 15;
            confirmBtn.BorderThickness = 2;
            confirmBtn.CustomizableEdges = customizableEdges3;
            confirmBtn.DisabledState.BorderColor = Color.DarkGray;
            confirmBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            confirmBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            confirmBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            confirmBtn.FillColor = Color.Teal;
            confirmBtn.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            confirmBtn.ForeColor = Color.White;
            confirmBtn.Location = new Point(609, 448);
            confirmBtn.Margin = new Padding(3, 4, 3, 4);
            confirmBtn.Name = "confirmBtn";
            confirmBtn.PressedColor = Color.DarkSlateGray;
            confirmBtn.ShadowDecoration.CustomizableEdges = customizableEdges4;
            confirmBtn.Size = new Size(161, 60);
            confirmBtn.TabIndex = 18;
            confirmBtn.Text = "Confirm";
            confirmBtn.Click += confirmBtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Teal;
            label1.Font = new Font("Segoe UI Emoji", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Transparent;
            label1.Location = new Point(609, 181);
            label1.Name = "label1";
            label1.Size = new Size(198, 27);
            label1.TabIndex = 17;
            label1.Text = "Enter Amount here:";
            // 
            // txtDepositCheq
            // 
            txtDepositCheq.BackColor = Color.Transparent;
            txtDepositCheq.BorderColor = Color.DarkSlateGray;
            txtDepositCheq.BorderRadius = 15;
            txtDepositCheq.BorderThickness = 2;
            txtDepositCheq.CustomizableEdges = customizableEdges5;
            txtDepositCheq.DefaultText = "";
            txtDepositCheq.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtDepositCheq.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtDepositCheq.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtDepositCheq.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtDepositCheq.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDepositCheq.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtDepositCheq.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDepositCheq.Location = new Point(588, 213);
            txtDepositCheq.Margin = new Padding(5, 4, 5, 4);
            txtDepositCheq.Name = "txtDepositCheq";
            txtDepositCheq.PasswordChar = '\0';
            txtDepositCheq.PlaceholderText = "Enter Amount";
            txtDepositCheq.SelectedText = "";
            txtDepositCheq.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtDepositCheq.Size = new Size(393, 73);
            txtDepositCheq.TabIndex = 16;
            txtDepositCheq.TextChanged += txtDepositCheq_TextChanged;
            // 
            // DepositCheque
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1119, 567);
            Controls.Add(CancelBtn);
            Controls.Add(confirmBtn);
            Controls.Add(label1);
            Controls.Add(txtDepositCheq);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(3, 4, 3, 4);
            Name = "DepositCheque";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "DepositCheque";
            Load += DepositCheque_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Guna.UI2.WinForms.Guna2Button CancelBtn;
        private Guna.UI2.WinForms.Guna2Button confirmBtn;
        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtDepositCheq;
    }
}