﻿namespace atmsystem
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            txtAccNum = new Guna.UI2.WinForms.Guna2TextBox();
            txtPIN = new Guna.UI2.WinForms.Guna2TextBox();
            ShowHidPIN = new Guna.UI2.WinForms.Guna2CheckBox();
            loginBtn = new Guna.UI2.WinForms.Guna2Button();
            cancelBtn = new Guna.UI2.WinForms.Guna2Button();
            SuspendLayout();
            // 
            // txtAccNum
            // 
            txtAccNum.BackColor = Color.Transparent;
            txtAccNum.BorderColor = Color.DarkCyan;
            txtAccNum.BorderRadius = 20;
            txtAccNum.BorderThickness = 2;
            txtAccNum.CustomizableEdges = customizableEdges1;
            txtAccNum.DefaultText = "";
            txtAccNum.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtAccNum.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtAccNum.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtAccNum.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtAccNum.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAccNum.Font = new Font("Segoe UI", 9F);
            txtAccNum.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAccNum.Location = new Point(87, 543);
            txtAccNum.Margin = new Padding(3, 5, 3, 5);
            txtAccNum.Name = "txtAccNum";
            txtAccNum.PasswordChar = '\0';
            txtAccNum.PlaceholderText = "Account Number";
            txtAccNum.SelectedText = "";
            txtAccNum.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtAccNum.Size = new Size(399, 76);
            txtAccNum.TabIndex = 1;
            txtAccNum.TextChanged += txtAccNum_TextChanged;
            // 
            // txtPIN
            // 
            txtPIN.BackColor = Color.Transparent;
            txtPIN.BorderColor = Color.DarkCyan;
            txtPIN.BorderRadius = 20;
            txtPIN.BorderThickness = 2;
            txtPIN.CustomizableEdges = customizableEdges3;
            txtPIN.DefaultText = "";
            txtPIN.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPIN.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPIN.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPIN.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPIN.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPIN.Font = new Font("Segoe UI", 9F);
            txtPIN.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPIN.Location = new Point(87, 628);
            txtPIN.Margin = new Padding(3, 5, 3, 5);
            txtPIN.Name = "txtPIN";
            txtPIN.PasswordChar = '\0';
            txtPIN.PlaceholderText = "PIN";
            txtPIN.SelectedText = "";
            txtPIN.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtPIN.Size = new Size(399, 76);
            txtPIN.TabIndex = 2;
            // 
            // ShowHidPIN
            // 
            ShowHidPIN.AutoSize = true;
            ShowHidPIN.BackColor = Color.Transparent;
            ShowHidPIN.CheckedState.BorderColor = Color.FromArgb(94, 148, 255);
            ShowHidPIN.CheckedState.BorderRadius = 0;
            ShowHidPIN.CheckedState.BorderThickness = 0;
            ShowHidPIN.CheckedState.FillColor = Color.FromArgb(94, 148, 255);
            ShowHidPIN.CheckMarkColor = Color.DarkSlateGray;
            ShowHidPIN.Font = new Font("Segoe UI Emoji", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ShowHidPIN.ForeColor = Color.DarkSlateGray;
            ShowHidPIN.Location = new Point(108, 713);
            ShowHidPIN.Margin = new Padding(3, 4, 3, 4);
            ShowHidPIN.Name = "ShowHidPIN";
            ShowHidPIN.Size = new Size(106, 26);
            ShowHidPIN.TabIndex = 3;
            ShowHidPIN.Text = "Show PIN";
            ShowHidPIN.UncheckedState.BorderColor = Color.FromArgb(125, 137, 149);
            ShowHidPIN.UncheckedState.BorderRadius = 0;
            ShowHidPIN.UncheckedState.BorderThickness = 0;
            ShowHidPIN.UncheckedState.FillColor = Color.FromArgb(125, 137, 149);
            ShowHidPIN.UseVisualStyleBackColor = false;
            ShowHidPIN.CheckedChanged += ShowHidPIN_CheckedChanged;
            // 
            // loginBtn
            // 
            loginBtn.BackColor = Color.Transparent;
            loginBtn.BorderColor = Color.DarkSlateGray;
            loginBtn.BorderRadius = 15;
            loginBtn.BorderThickness = 2;
            loginBtn.CustomizableEdges = customizableEdges5;
            loginBtn.DisabledState.BorderColor = Color.DarkGray;
            loginBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            loginBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            loginBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            loginBtn.FillColor = Color.Teal;
            loginBtn.Font = new Font("Sitka Small", 12F, FontStyle.Bold);
            loginBtn.ForeColor = Color.White;
            loginBtn.Location = new Point(87, 872);
            loginBtn.Margin = new Padding(3, 4, 3, 4);
            loginBtn.Name = "loginBtn";
            loginBtn.ShadowDecoration.CustomizableEdges = customizableEdges6;
            loginBtn.Size = new Size(141, 57);
            loginBtn.TabIndex = 4;
            loginBtn.Text = "Log in";
            loginBtn.Click += loginBtn_Click;
            // 
            // cancelBtn
            // 
            cancelBtn.BackColor = Color.Transparent;
            cancelBtn.BorderColor = Color.DarkSlateGray;
            cancelBtn.BorderRadius = 15;
            cancelBtn.BorderThickness = 2;
            cancelBtn.CustomizableEdges = customizableEdges7;
            cancelBtn.DisabledState.BorderColor = Color.DarkGray;
            cancelBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            cancelBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            cancelBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            cancelBtn.FillColor = Color.Teal;
            cancelBtn.Font = new Font("Sitka Small", 12F, FontStyle.Bold);
            cancelBtn.ForeColor = Color.White;
            cancelBtn.Location = new Point(345, 872);
            cancelBtn.Margin = new Padding(3, 4, 3, 4);
            cancelBtn.Name = "cancelBtn";
            cancelBtn.ShadowDecoration.CustomizableEdges = customizableEdges8;
            cancelBtn.Size = new Size(141, 57);
            cancelBtn.TabIndex = 6;
            cancelBtn.Text = "Cancel";
            cancelBtn.Click += cancelBtn_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(570, 1033);
            Controls.Add(cancelBtn);
            Controls.Add(loginBtn);
            Controls.Add(ShowHidPIN);
            Controls.Add(txtPIN);
            Controls.Add(txtAccNum);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Guna.UI2.WinForms.Guna2TextBox txtAccNum;
        private Guna.UI2.WinForms.Guna2TextBox txtPIN;
        private Guna.UI2.WinForms.Guna2CheckBox ShowHidPIN;
        private Guna.UI2.WinForms.Guna2Button loginBtn;
        private Guna.UI2.WinForms.Guna2Button cancelBtn;
    }
}
