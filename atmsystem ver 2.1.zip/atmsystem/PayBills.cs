﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.DirectoryServices.ActiveDirectory;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atmsystem
{
    public partial class PayBills : Form
    {
        private string selectedCard;
        double paymentAmount;
        string selectedCompany;
        string selectedCompanyElectric;
        public PayBills()
        {
            InitializeComponent();
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            MainPage backtoMain = new MainPage();
            this.Hide();
            backtoMain.Show();
        }

        private void ElectricityBillBtn_Click(object sender, EventArgs e)
        {
            ElectricityBilPanel.Visible = true;
            ElectricityBilPanel.BringToFront();

            // Hide other panels
            WaterBillPanel.Visible = false;
            CreditCardPanel.Visible = false;
        }

        private void WaterBillBtn_Click(object sender, EventArgs e)
        {
            WaterBillPanel.BringToFront();
            WaterBillPanel.Visible = true;
        }

        private void CreditCardBtn_Click(object sender, EventArgs e)
        {
            CreditCardPanel.Visible = true;
            WaterBillPanel.Visible = false;
            ElectricityBilPanel.Visible = false;
        }

        private void PayBills_Load(object sender, EventArgs e)
        {
            CreditCardPanel.Visible = false;
            WaterBillPanel.Visible = false;
            ElectricityBilPanel.Visible = false;
        }

        private void ElectricityBilPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void WaterBillPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtAmounWb_TextChanged(object sender, EventArgs e)
        {
            //BtnConfirm
            double amountWb;
            if (!double.TryParse(txtAmounWb.Text, out amountWb))
            {
                txtAmounWb.Text = "";
            }
            else if(amountWb > AccountInfo.savingsAmount)
            {
                BtnConfirm.Enabled = false;
            }
            else
            {
                BtnConfirm.Enabled = true;
            }

        }

        private void txtAmountEb_TextChanged(object sender, EventArgs e)
        {
            double amountEb;
            if (!double.TryParse(txtAmountEb.Text, out amountEb))
            {
                txtAmountEb.Text = "";
            }
            else if (amountEb > AccountInfo.savingsAmount)
            {
                ConffrmBtn.Enabled = false;
            }
            else
            {
                ConffrmBtn.Enabled = true;
            }
        }

        private void txtAmountCc_TextChanged(object sender, EventArgs e)
        {
            double amountCc;
            if (!double.TryParse(txtAmountCc.Text, out amountCc))
            {
                txtAmountCc.Text = "";
            }
            else if(amountCc > AccountInfo.savingsAmount)
            {
                ConfirmBtn.Enabled = false;
            }
            else
            {
                ConfirmBtn.Enabled = true;
            }
        }

        private void CancelEb_Click(object sender, EventArgs e)
        {
            ElectricityBilPanel.Visible = false;
        }

        private void CancelWb_Click(object sender, EventArgs e)
        {
            WaterBillPanel.Visible = false;
        }

        private void CancelCc_Click(object sender, EventArgs e)
        {
            CreditCardPanel.Visible = false;
        }

        private void CreditCardChoice_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CreditCardChoice.SelectedItem != null)
            {
                selectedCard = CreditCardChoice.SelectedItem.ToString();

                switch (selectedCard)
                {
                    case "LandBank":
                    case "Visa":
                    case "UnionBank":
                    case "Mastercard":
                        // Pass the selected card to the next form
                        PayBillsReceipt receiptForm = new PayBillsReceipt(selectedCompany, selectedCompany, selectedCard, paymentAmount, AccountInfo.savingsAmount);
                        break;
                    default:
                        // Display an error message for an invalid credit card choice
                        MessageBox.Show("Invalid credit card choice.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
            }
            else
            {
                // Handle the case where selected card is null
                MessageBox.Show("Please select a credit card.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ConfirmBtn_Click(object sender, EventArgs e)
        {

            if (!double.TryParse(txtAmountCc.Text, out paymentAmount))
            {
                MessageBox.Show("Invalid amount", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (paymentAmount > AccountInfo.savingsAmount)
            {
                MessageBox.Show("Insufficient balance", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Subtract the payment amount from savingsAmount
            AccountInfo.savingsAmount -= paymentAmount;

            // Pass the payment amount to PayBillsReceipt
            PayBillsReceipt receiptForm = new PayBillsReceipt(selectedCompany, selectedCompany, selectedCard, paymentAmount, AccountInfo.savingsAmount);
            this.Hide();
            receiptForm.Show();
        }

        private void WaterCompChoice_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedCompany = WaterCompChoice.SelectedItem.ToString();

            switch (selectedCompany)
            {
                case "MAYNILAD WATER SERVICES, INC.":
                case "PRIMEWATER INFRASTRUCTURE CORP.":
                case "LAGUNA AAA WATER CORPORATION":
                case "METROPOLITAN CEBU WATER DISTRICT":
                    // Pass the selected company to the next form
                    PayBillsReceipt nextForm = new PayBillsReceipt(selectedCompany, selectedCompany, selectedCard, paymentAmount, AccountInfo.savingsAmount);
                    break;
                default:
                    MessageBox.Show("Invalid water company choice.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        private void ElectricBillChoice_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedCompanyElectric = ElectricBillChoice.SelectedItem.ToString();
            switch (selectedCompanyElectric)
            {
                case "Meralco":
                case "Pelco":
                case "Presco":
                case "SFELAPCO":
                    // Pass the selected company to the next form
                    PayBillsReceipt receiptForm = new PayBillsReceipt(selectedCompanyElectric, selectedCompanyElectric, selectedCard, paymentAmount, AccountInfo.savingsAmount);
                    break;
                default:
                    // Display an error message for an invalid selection
                    MessageBox.Show("Invalid electric company choice.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break;
            }
        }

        private void ConffrmBtn_Click(object sender, EventArgs e)
        {
            double paymentAmount;
            if (!double.TryParse(txtAmountEb.Text, out paymentAmount))
            {
                MessageBox.Show("Invalid payment amount", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Subtract payment amount from savingsAmount
            AccountInfo.savingsAmount -= paymentAmount;

            // Pass the payment amount to the next form
            PayBillsReceipt receiptForm = new PayBillsReceipt(selectedCompany, selectedCompany, selectedCard, paymentAmount, AccountInfo.savingsAmount);
            this.Hide();
            receiptForm.Show();
        }

        private void BtnConfirm_Click(object sender, EventArgs e)
        {
            double paymentAmount;
            if (!double.TryParse(txtAmounWb.Text, out paymentAmount))
            {
                MessageBox.Show("Invalid payment amount", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Subtract payment amount from savingsAmount
            AccountInfo.savingsAmount -= paymentAmount;

            // Pass the payment amount to the next form
            PayBillsReceipt receiptForm = new PayBillsReceipt(selectedCompany, selectedCompany, selectedCard, paymentAmount, AccountInfo.savingsAmount);
            this.Hide();
            receiptForm.Show();
        }
    }
}
