﻿namespace atmsystem
{
    partial class PayBills
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges39 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges40 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges41 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges42 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges43 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges44 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges45 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges46 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PayBills));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges55 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges56 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges65 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges66 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges57 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges58 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges75 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges76 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges67 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges68 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges69 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges70 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges71 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges72 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges73 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges74 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges59 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges60 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges61 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges62 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges63 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges64 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges47 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges48 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges49 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges50 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges51 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges52 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges53 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges54 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            cancelBtn = new Guna.UI2.WinForms.Guna2Button();
            WaterBillBtn = new Guna.UI2.WinForms.Guna2Button();
            CreditCardBtn = new Guna.UI2.WinForms.Guna2Button();
            ElectricityBillBtn = new Guna.UI2.WinForms.Guna2Button();
            CreditCardPanel = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            WaterBillPanel = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            CancelWb = new Guna.UI2.WinForms.Guna2Button();
            ElectricityBilPanel = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            CancelEb = new Guna.UI2.WinForms.Guna2Button();
            guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            txtAmountEb = new Guna.UI2.WinForms.Guna2TextBox();
            ConffrmBtn = new Guna.UI2.WinForms.Guna2Button();
            ElectricBillChoice = new Guna.UI2.WinForms.Guna2ComboBox();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            txtAmounWb = new Guna.UI2.WinForms.Guna2TextBox();
            BtnConfirm = new Guna.UI2.WinForms.Guna2Button();
            WaterCompChoice = new Guna.UI2.WinForms.Guna2ComboBox();
            CancelCc = new Guna.UI2.WinForms.Guna2Button();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            txtAmountCc = new Guna.UI2.WinForms.Guna2TextBox();
            ConfirmBtn = new Guna.UI2.WinForms.Guna2Button();
            CreditCardChoice = new Guna.UI2.WinForms.Guna2ComboBox();
            CreditCardPanel.SuspendLayout();
            WaterBillPanel.SuspendLayout();
            ElectricityBilPanel.SuspendLayout();
            SuspendLayout();
            // 
            // cancelBtn
            // 
            cancelBtn.BackColor = Color.Transparent;
            cancelBtn.BorderColor = Color.DarkSlateGray;
            cancelBtn.BorderRadius = 15;
            cancelBtn.BorderThickness = 2;
            cancelBtn.CustomizableEdges = customizableEdges39;
            cancelBtn.DisabledState.BorderColor = Color.DarkGray;
            cancelBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            cancelBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            cancelBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            cancelBtn.FillColor = Color.Teal;
            cancelBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cancelBtn.ForeColor = Color.White;
            cancelBtn.Location = new Point(128, 595);
            cancelBtn.Name = "cancelBtn";
            cancelBtn.ShadowDecoration.CustomizableEdges = customizableEdges40;
            cancelBtn.Size = new Size(235, 48);
            cancelBtn.TabIndex = 12;
            cancelBtn.Text = "Cancel";
            cancelBtn.Click += cancelBtn_Click;
            // 
            // WaterBillBtn
            // 
            WaterBillBtn.BackColor = Color.Transparent;
            WaterBillBtn.BorderColor = Color.DarkSlateGray;
            WaterBillBtn.BorderRadius = 15;
            WaterBillBtn.BorderThickness = 2;
            WaterBillBtn.CustomizableEdges = customizableEdges41;
            WaterBillBtn.DisabledState.BorderColor = Color.DarkGray;
            WaterBillBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            WaterBillBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            WaterBillBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            WaterBillBtn.FillColor = Color.Teal;
            WaterBillBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            WaterBillBtn.ForeColor = Color.White;
            WaterBillBtn.Location = new Point(128, 488);
            WaterBillBtn.Name = "WaterBillBtn";
            WaterBillBtn.ShadowDecoration.CustomizableEdges = customizableEdges42;
            WaterBillBtn.Size = new Size(235, 48);
            WaterBillBtn.TabIndex = 11;
            WaterBillBtn.Text = "Water Bill";
            WaterBillBtn.Click += WaterBillBtn_Click;
            // 
            // CreditCardBtn
            // 
            CreditCardBtn.BackColor = Color.Transparent;
            CreditCardBtn.BorderColor = Color.DarkSlateGray;
            CreditCardBtn.BorderRadius = 15;
            CreditCardBtn.BorderThickness = 2;
            CreditCardBtn.CustomizableEdges = customizableEdges43;
            CreditCardBtn.DisabledState.BorderColor = Color.DarkGray;
            CreditCardBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            CreditCardBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            CreditCardBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            CreditCardBtn.FillColor = Color.Teal;
            CreditCardBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CreditCardBtn.ForeColor = Color.White;
            CreditCardBtn.Location = new Point(128, 434);
            CreditCardBtn.Name = "CreditCardBtn";
            CreditCardBtn.ShadowDecoration.CustomizableEdges = customizableEdges44;
            CreditCardBtn.Size = new Size(235, 48);
            CreditCardBtn.TabIndex = 10;
            CreditCardBtn.Text = "Credit Card";
            CreditCardBtn.Click += CreditCardBtn_Click;
            // 
            // ElectricityBillBtn
            // 
            ElectricityBillBtn.BackColor = Color.Transparent;
            ElectricityBillBtn.BorderColor = Color.DarkSlateGray;
            ElectricityBillBtn.BorderRadius = 15;
            ElectricityBillBtn.BorderThickness = 2;
            ElectricityBillBtn.CustomizableEdges = customizableEdges45;
            ElectricityBillBtn.DisabledState.BorderColor = Color.DarkGray;
            ElectricityBillBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            ElectricityBillBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            ElectricityBillBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            ElectricityBillBtn.FillColor = Color.Teal;
            ElectricityBillBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ElectricityBillBtn.ForeColor = Color.White;
            ElectricityBillBtn.Location = new Point(128, 541);
            ElectricityBillBtn.Name = "ElectricityBillBtn";
            ElectricityBillBtn.ShadowDecoration.CustomizableEdges = customizableEdges46;
            ElectricityBillBtn.Size = new Size(235, 48);
            ElectricityBillBtn.TabIndex = 13;
            ElectricityBillBtn.Text = "Electricity Bill";
            ElectricityBillBtn.Click += ElectricityBillBtn_Click;
            // 
            // CreditCardPanel
            // 
            CreditCardPanel.BackColor = Color.LightCyan;
            CreditCardPanel.BackgroundImage = (Image)resources.GetObject("CreditCardPanel.BackgroundImage");
            CreditCardPanel.BackgroundImageLayout = ImageLayout.Stretch;
            CreditCardPanel.Controls.Add(CancelCc);
            CreditCardPanel.Controls.Add(guna2HtmlLabel1);
            CreditCardPanel.Controls.Add(txtAmountCc);
            CreditCardPanel.Controls.Add(ConfirmBtn);
            CreditCardPanel.Controls.Add(CreditCardChoice);
            CreditCardPanel.CustomizableEdges = customizableEdges55;
            CreditCardPanel.FillColor = Color.Transparent;
            CreditCardPanel.FillColor2 = Color.Transparent;
            CreditCardPanel.FillColor3 = Color.Transparent;
            CreditCardPanel.FillColor4 = Color.Transparent;
            CreditCardPanel.Location = new Point(111, 331);
            CreditCardPanel.Name = "CreditCardPanel";
            CreditCardPanel.ShadowDecoration.CustomizableEdges = customizableEdges56;
            CreditCardPanel.Size = new Size(276, 333);
            CreditCardPanel.TabIndex = 14;
            // 
            // WaterBillPanel
            // 
            WaterBillPanel.BackColor = Color.LightCyan;
            WaterBillPanel.BackgroundImage = (Image)resources.GetObject("WaterBillPanel.BackgroundImage");
            WaterBillPanel.BackgroundImageLayout = ImageLayout.Stretch;
            WaterBillPanel.Controls.Add(CancelWb);
            WaterBillPanel.Controls.Add(guna2HtmlLabel2);
            WaterBillPanel.Controls.Add(txtAmounWb);
            WaterBillPanel.Controls.Add(BtnConfirm);
            WaterBillPanel.Controls.Add(WaterCompChoice);
            WaterBillPanel.CustomizableEdges = customizableEdges65;
            WaterBillPanel.FillColor = Color.Transparent;
            WaterBillPanel.FillColor2 = Color.Transparent;
            WaterBillPanel.FillColor3 = Color.Transparent;
            WaterBillPanel.FillColor4 = Color.Transparent;
            WaterBillPanel.Location = new Point(111, 331);
            WaterBillPanel.Name = "WaterBillPanel";
            WaterBillPanel.ShadowDecoration.CustomizableEdges = customizableEdges66;
            WaterBillPanel.Size = new Size(279, 333);
            WaterBillPanel.TabIndex = 16;
            WaterBillPanel.Paint += WaterBillPanel_Paint;
            // 
            // CancelWb
            // 
            CancelWb.BackColor = Color.Transparent;
            CancelWb.BorderColor = Color.DarkSlateGray;
            CancelWb.BorderRadius = 15;
            CancelWb.BorderThickness = 2;
            CancelWb.CustomizableEdges = customizableEdges57;
            CancelWb.DisabledState.BorderColor = Color.DarkGray;
            CancelWb.DisabledState.CustomBorderColor = Color.DarkGray;
            CancelWb.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            CancelWb.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            CancelWb.FillColor = Color.Teal;
            CancelWb.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CancelWb.ForeColor = Color.White;
            CancelWb.Location = new Point(9, 278);
            CancelWb.Name = "CancelWb";
            CancelWb.ShadowDecoration.CustomizableEdges = customizableEdges58;
            CancelWb.Size = new Size(98, 38);
            CancelWb.TabIndex = 16;
            CancelWb.Text = "Cancel";
            CancelWb.Click += CancelWb_Click;
            // 
            // ElectricityBilPanel
            // 
            ElectricityBilPanel.BackColor = Color.LightCyan;
            ElectricityBilPanel.BackgroundImage = (Image)resources.GetObject("ElectricityBilPanel.BackgroundImage");
            ElectricityBilPanel.BackgroundImageLayout = ImageLayout.Stretch;
            ElectricityBilPanel.Controls.Add(CancelEb);
            ElectricityBilPanel.Controls.Add(guna2HtmlLabel3);
            ElectricityBilPanel.Controls.Add(txtAmountEb);
            ElectricityBilPanel.Controls.Add(ConffrmBtn);
            ElectricityBilPanel.Controls.Add(ElectricBillChoice);
            ElectricityBilPanel.CustomizableEdges = customizableEdges75;
            ElectricityBilPanel.FillColor = Color.Transparent;
            ElectricityBilPanel.FillColor2 = Color.Transparent;
            ElectricityBilPanel.FillColor3 = Color.Transparent;
            ElectricityBilPanel.FillColor4 = Color.Transparent;
            ElectricityBilPanel.Location = new Point(111, 331);
            ElectricityBilPanel.Name = "ElectricityBilPanel";
            ElectricityBilPanel.ShadowDecoration.CustomizableEdges = customizableEdges76;
            ElectricityBilPanel.Size = new Size(279, 333);
            ElectricityBilPanel.TabIndex = 17;
            ElectricityBilPanel.Paint += ElectricityBilPanel_Paint;
            // 
            // CancelEb
            // 
            CancelEb.BackColor = Color.Transparent;
            CancelEb.BorderColor = Color.DarkSlateGray;
            CancelEb.BorderRadius = 15;
            CancelEb.BorderThickness = 2;
            CancelEb.CustomizableEdges = customizableEdges67;
            CancelEb.DisabledState.BorderColor = Color.DarkGray;
            CancelEb.DisabledState.CustomBorderColor = Color.DarkGray;
            CancelEb.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            CancelEb.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            CancelEb.FillColor = Color.Teal;
            CancelEb.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CancelEb.ForeColor = Color.White;
            CancelEb.Location = new Point(9, 277);
            CancelEb.Name = "CancelEb";
            CancelEb.ShadowDecoration.CustomizableEdges = customizableEdges68;
            CancelEb.Size = new Size(98, 38);
            CancelEb.TabIndex = 16;
            CancelEb.Text = "Cancel";
            CancelEb.Click += CancelEb_Click;
            // 
            // guna2HtmlLabel3
            // 
            guna2HtmlLabel3.BackColor = Color.Transparent;
            guna2HtmlLabel3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel3.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel3.Location = new Point(20, 140);
            guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            guna2HtmlLabel3.Size = new Size(153, 23);
            guna2HtmlLabel3.TabIndex = 15;
            guna2HtmlLabel3.Text = "Enter Amount Here:";
            // 
            // txtAmountEb
            // 
            txtAmountEb.BackColor = Color.Transparent;
            txtAmountEb.BorderColor = Color.DarkSlateGray;
            txtAmountEb.BorderRadius = 15;
            txtAmountEb.BorderThickness = 2;
            txtAmountEb.CustomizableEdges = customizableEdges69;
            txtAmountEb.DefaultText = "";
            txtAmountEb.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtAmountEb.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtAmountEb.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtAmountEb.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtAmountEb.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAmountEb.Font = new Font("Segoe UI", 9F);
            txtAmountEb.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAmountEb.Location = new Point(9, 169);
            txtAmountEb.Name = "txtAmountEb";
            txtAmountEb.PasswordChar = '\0';
            txtAmountEb.PlaceholderText = "";
            txtAmountEb.SelectedText = "";
            txtAmountEb.ShadowDecoration.CustomizableEdges = customizableEdges70;
            txtAmountEb.Size = new Size(252, 39);
            txtAmountEb.TabIndex = 14;
            txtAmountEb.TextChanged += txtAmountEb_TextChanged;
            // 
            // ConffrmBtn
            // 
            ConffrmBtn.BackColor = Color.Transparent;
            ConffrmBtn.BorderColor = Color.DarkSlateGray;
            ConffrmBtn.BorderRadius = 15;
            ConffrmBtn.BorderThickness = 2;
            ConffrmBtn.CustomizableEdges = customizableEdges71;
            ConffrmBtn.DisabledState.BorderColor = Color.DarkGray;
            ConffrmBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            ConffrmBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            ConffrmBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            ConffrmBtn.FillColor = Color.Teal;
            ConffrmBtn.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ConffrmBtn.ForeColor = Color.White;
            ConffrmBtn.Location = new Point(163, 277);
            ConffrmBtn.Name = "ConffrmBtn";
            ConffrmBtn.ShadowDecoration.CustomizableEdges = customizableEdges72;
            ConffrmBtn.Size = new Size(98, 38);
            ConffrmBtn.TabIndex = 13;
            ConffrmBtn.Text = "Confirm";
            ConffrmBtn.Click += ConffrmBtn_Click;
            // 
            // ElectricBillChoice
            // 
            ElectricBillChoice.BackColor = Color.Transparent;
            ElectricBillChoice.BorderColor = Color.DarkSlateGray;
            ElectricBillChoice.BorderRadius = 10;
            ElectricBillChoice.BorderThickness = 2;
            ElectricBillChoice.CustomizableEdges = customizableEdges73;
            ElectricBillChoice.DrawMode = DrawMode.OwnerDrawFixed;
            ElectricBillChoice.DropDownStyle = ComboBoxStyle.DropDownList;
            ElectricBillChoice.FocusedColor = Color.FromArgb(94, 148, 255);
            ElectricBillChoice.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            ElectricBillChoice.Font = new Font("Segoe UI", 10F);
            ElectricBillChoice.ForeColor = Color.DarkSlateGray;
            ElectricBillChoice.ItemHeight = 30;
            ElectricBillChoice.Items.AddRange(new object[] { "Meralco", "Pelco", "Presco", "SFELAPCO" });
            ElectricBillChoice.Location = new Point(9, 75);
            ElectricBillChoice.Name = "ElectricBillChoice";
            ElectricBillChoice.ShadowDecoration.CustomizableEdges = customizableEdges74;
            ElectricBillChoice.Size = new Size(180, 36);
            ElectricBillChoice.TabIndex = 0;
            ElectricBillChoice.SelectedIndexChanged += ElectricBillChoice_SelectedIndexChanged;
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel2.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel2.Location = new Point(20, 140);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(153, 23);
            guna2HtmlLabel2.TabIndex = 15;
            guna2HtmlLabel2.Text = "Enter Amount Here:";
            // 
            // txtAmounWb
            // 
            txtAmounWb.BackColor = Color.Transparent;
            txtAmounWb.BorderColor = Color.DarkSlateGray;
            txtAmounWb.BorderRadius = 15;
            txtAmounWb.BorderThickness = 2;
            txtAmounWb.CustomizableEdges = customizableEdges59;
            txtAmounWb.DefaultText = "";
            txtAmounWb.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtAmounWb.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtAmounWb.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtAmounWb.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtAmounWb.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAmounWb.Font = new Font("Segoe UI", 9F);
            txtAmounWb.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAmounWb.Location = new Point(9, 169);
            txtAmounWb.Name = "txtAmounWb";
            txtAmounWb.PasswordChar = '\0';
            txtAmounWb.PlaceholderText = "";
            txtAmounWb.SelectedText = "";
            txtAmounWb.ShadowDecoration.CustomizableEdges = customizableEdges60;
            txtAmounWb.Size = new Size(252, 39);
            txtAmounWb.TabIndex = 14;
            txtAmounWb.TextChanged += txtAmounWb_TextChanged;
            // 
            // BtnConfirm
            // 
            BtnConfirm.BackColor = Color.Transparent;
            BtnConfirm.BorderColor = Color.DarkSlateGray;
            BtnConfirm.BorderRadius = 15;
            BtnConfirm.BorderThickness = 2;
            BtnConfirm.CustomizableEdges = customizableEdges61;
            BtnConfirm.DisabledState.BorderColor = Color.DarkGray;
            BtnConfirm.DisabledState.CustomBorderColor = Color.DarkGray;
            BtnConfirm.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            BtnConfirm.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            BtnConfirm.FillColor = Color.Teal;
            BtnConfirm.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnConfirm.ForeColor = Color.White;
            BtnConfirm.Location = new Point(158, 279);
            BtnConfirm.Name = "BtnConfirm";
            BtnConfirm.ShadowDecoration.CustomizableEdges = customizableEdges62;
            BtnConfirm.Size = new Size(103, 37);
            BtnConfirm.TabIndex = 13;
            BtnConfirm.Text = "Confirm";
            BtnConfirm.Click += BtnConfirm_Click;
            // 
            // WaterCompChoice
            // 
            WaterCompChoice.BackColor = Color.Transparent;
            WaterCompChoice.BorderColor = Color.DarkSlateGray;
            WaterCompChoice.BorderRadius = 10;
            WaterCompChoice.BorderThickness = 2;
            WaterCompChoice.CustomizableEdges = customizableEdges63;
            WaterCompChoice.DrawMode = DrawMode.OwnerDrawFixed;
            WaterCompChoice.DropDownStyle = ComboBoxStyle.DropDownList;
            WaterCompChoice.FocusedColor = Color.FromArgb(94, 148, 255);
            WaterCompChoice.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            WaterCompChoice.Font = new Font("Segoe UI", 10F);
            WaterCompChoice.ForeColor = Color.DarkSlateGray;
            WaterCompChoice.ItemHeight = 30;
            WaterCompChoice.Items.AddRange(new object[] { "MAYNILAD WATER SERVICES, INC.", "PRIMEWATER INFRASTRUCTURE CORP.", "LAGUNA AAA WATER CORPORATION", "METROPOLITAN CEBU WATER DISTRICT" });
            WaterCompChoice.Location = new Point(9, 75);
            WaterCompChoice.Name = "WaterCompChoice";
            WaterCompChoice.ShadowDecoration.CustomizableEdges = customizableEdges64;
            WaterCompChoice.Size = new Size(180, 36);
            WaterCompChoice.TabIndex = 0;
            WaterCompChoice.SelectedIndexChanged += WaterCompChoice_SelectedIndexChanged;
            // 
            // CancelCc
            // 
            CancelCc.BackColor = Color.Transparent;
            CancelCc.BorderColor = Color.DarkSlateGray;
            CancelCc.BorderRadius = 15;
            CancelCc.BorderThickness = 2;
            CancelCc.CustomizableEdges = customizableEdges47;
            CancelCc.DisabledState.BorderColor = Color.DarkGray;
            CancelCc.DisabledState.CustomBorderColor = Color.DarkGray;
            CancelCc.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            CancelCc.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            CancelCc.FillColor = Color.Teal;
            CancelCc.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CancelCc.ForeColor = Color.White;
            CancelCc.Location = new Point(9, 278);
            CancelCc.Name = "CancelCc";
            CancelCc.ShadowDecoration.CustomizableEdges = customizableEdges48;
            CancelCc.Size = new Size(98, 38);
            CancelCc.TabIndex = 18;
            CancelCc.Text = "Cancel";
            CancelCc.Click += CancelCc_Click;
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = Color.DarkSlateGray;
            guna2HtmlLabel1.Location = new Point(20, 140);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(153, 23);
            guna2HtmlLabel1.TabIndex = 15;
            guna2HtmlLabel1.Text = "Enter Amount Here:";
            // 
            // txtAmountCc
            // 
            txtAmountCc.BackColor = Color.Transparent;
            txtAmountCc.BorderColor = Color.DarkSlateGray;
            txtAmountCc.BorderRadius = 15;
            txtAmountCc.BorderThickness = 2;
            txtAmountCc.CustomizableEdges = customizableEdges49;
            txtAmountCc.DefaultText = "";
            txtAmountCc.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtAmountCc.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtAmountCc.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtAmountCc.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtAmountCc.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAmountCc.Font = new Font("Segoe UI", 9F);
            txtAmountCc.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAmountCc.Location = new Point(9, 169);
            txtAmountCc.Name = "txtAmountCc";
            txtAmountCc.PasswordChar = '\0';
            txtAmountCc.PlaceholderText = "";
            txtAmountCc.SelectedText = "";
            txtAmountCc.ShadowDecoration.CustomizableEdges = customizableEdges50;
            txtAmountCc.Size = new Size(252, 39);
            txtAmountCc.TabIndex = 14;
            txtAmountCc.TextChanged += txtAmountCc_TextChanged;
            // 
            // ConfirmBtn
            // 
            ConfirmBtn.BackColor = Color.Transparent;
            ConfirmBtn.BorderColor = Color.DarkSlateGray;
            ConfirmBtn.BorderRadius = 15;
            ConfirmBtn.BorderThickness = 2;
            ConfirmBtn.CustomizableEdges = customizableEdges51;
            ConfirmBtn.DisabledState.BorderColor = Color.DarkGray;
            ConfirmBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            ConfirmBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            ConfirmBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            ConfirmBtn.FillColor = Color.Teal;
            ConfirmBtn.Font = new Font("Sitka Small", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ConfirmBtn.ForeColor = Color.White;
            ConfirmBtn.Location = new Point(157, 279);
            ConfirmBtn.Name = "ConfirmBtn";
            ConfirmBtn.ShadowDecoration.CustomizableEdges = customizableEdges52;
            ConfirmBtn.Size = new Size(98, 37);
            ConfirmBtn.TabIndex = 13;
            ConfirmBtn.Text = "Confirm";
            ConfirmBtn.Click += ConfirmBtn_Click;
            // 
            // CreditCardChoice
            // 
            CreditCardChoice.BackColor = Color.Transparent;
            CreditCardChoice.BorderColor = Color.DarkSlateGray;
            CreditCardChoice.BorderRadius = 10;
            CreditCardChoice.BorderThickness = 2;
            CreditCardChoice.CustomizableEdges = customizableEdges53;
            CreditCardChoice.DrawMode = DrawMode.OwnerDrawFixed;
            CreditCardChoice.DropDownStyle = ComboBoxStyle.DropDownList;
            CreditCardChoice.FocusedColor = Color.FromArgb(94, 148, 255);
            CreditCardChoice.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            CreditCardChoice.Font = new Font("Segoe UI", 10F);
            CreditCardChoice.ForeColor = Color.DarkSlateGray;
            CreditCardChoice.ItemHeight = 30;
            CreditCardChoice.Items.AddRange(new object[] { "LandBank", "Visa", "UnionBank", "Mastercard" });
            CreditCardChoice.Location = new Point(9, 75);
            CreditCardChoice.Name = "CreditCardChoice";
            CreditCardChoice.ShadowDecoration.CustomizableEdges = customizableEdges54;
            CreditCardChoice.Size = new Size(180, 36);
            CreditCardChoice.TabIndex = 0;
            CreditCardChoice.SelectedIndexChanged += CreditCardChoice_SelectedIndexChanged;
            // 
            // PayBills
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(500, 723);
            Controls.Add(WaterBillPanel);
            Controls.Add(ElectricityBilPanel);
            Controls.Add(CreditCardPanel);
            Controls.Add(ElectricityBillBtn);
            Controls.Add(cancelBtn);
            Controls.Add(WaterBillBtn);
            Controls.Add(CreditCardBtn);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "PayBills";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "PayBills";
            Load += PayBills_Load;
            CreditCardPanel.ResumeLayout(false);
            CreditCardPanel.PerformLayout();
            WaterBillPanel.ResumeLayout(false);
            WaterBillPanel.PerformLayout();
            ElectricityBilPanel.ResumeLayout(false);
            ElectricityBilPanel.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button cancelBtn;
        private Guna.UI2.WinForms.Guna2Button WaterBillBtn;
        private Guna.UI2.WinForms.Guna2Button CreditCardBtn;
        private Guna.UI2.WinForms.Guna2Button ElectricityBillBtn;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel CreditCardPanel;
        private Guna.UI2.WinForms.Guna2ComboBox CreditCardChoice;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2TextBox txtAmountCc;
        private Guna.UI2.WinForms.Guna2Button ConfirmBtn;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel WaterBillPanel;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2TextBox txtAmounWb;
        private Guna.UI2.WinForms.Guna2Button BtnConfirm;
        private Guna.UI2.WinForms.Guna2ComboBox WaterCompChoice;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel ElectricityBilPanel;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2TextBox txtAmountEb;
        private Guna.UI2.WinForms.Guna2Button ConffrmBtn;
        private Guna.UI2.WinForms.Guna2ComboBox ElectricBillChoice;
        private Guna.UI2.WinForms.Guna2Button CancelCc;
        private Guna.UI2.WinForms.Guna2Button CancelWb;
        private Guna.UI2.WinForms.Guna2Button CancelEb;
    }
}