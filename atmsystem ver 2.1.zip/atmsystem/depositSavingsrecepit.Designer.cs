﻿namespace atmsystem
{
    partial class depositSavingsrecepit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(depositSavingsrecepit));
            proceedBtn = new Guna.UI2.WinForms.Guna2Button();
            lblCurrentBalAdd = new Label();
            lblAmountAdded = new Label();
            lblAccNum = new Label();
            SuspendLayout();
            // 
            // proceedBtn
            // 
            proceedBtn.BackColor = Color.Transparent;
            proceedBtn.BorderColor = Color.DarkSlateGray;
            proceedBtn.BorderRadius = 15;
            proceedBtn.BorderThickness = 2;
            proceedBtn.CustomizableEdges = customizableEdges1;
            proceedBtn.DisabledState.BorderColor = Color.DarkGray;
            proceedBtn.DisabledState.CustomBorderColor = Color.DarkGray;
            proceedBtn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            proceedBtn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            proceedBtn.FillColor = Color.Teal;
            proceedBtn.Font = new Font("Sitka Small", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            proceedBtn.ForeColor = Color.White;
            proceedBtn.Location = new Point(400, 286);
            proceedBtn.Name = "proceedBtn";
            proceedBtn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            proceedBtn.Size = new Size(295, 42);
            proceedBtn.TabIndex = 25;
            proceedBtn.Text = "Proceed to Merchant";
            proceedBtn.Click += proceedBtn_Click;
            // 
            // lblCurrentBalAdd
            // 
            lblCurrentBalAdd.AutoSize = true;
            lblCurrentBalAdd.BackColor = Color.Transparent;
            lblCurrentBalAdd.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold);
            lblCurrentBalAdd.ForeColor = Color.DarkSlateGray;
            lblCurrentBalAdd.Location = new Point(599, 238);
            lblCurrentBalAdd.Name = "lblCurrentBalAdd";
            lblCurrentBalAdd.Size = new Size(39, 26);
            lblCurrentBalAdd.TabIndex = 24;
            lblCurrentBalAdd.Text = "---";
            lblCurrentBalAdd.Click += lblCurrentBalAdd_Click;
            // 
            // lblAmountAdded
            // 
            lblAmountAdded.AutoSize = true;
            lblAmountAdded.BackColor = Color.Transparent;
            lblAmountAdded.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold);
            lblAmountAdded.ForeColor = Color.DarkSlateGray;
            lblAmountAdded.Location = new Point(599, 190);
            lblAmountAdded.Name = "lblAmountAdded";
            lblAmountAdded.Size = new Size(39, 26);
            lblAmountAdded.TabIndex = 23;
            lblAmountAdded.Text = "---";
            lblAmountAdded.Click += lblAmountAdded_Click;
            // 
            // lblAccNum
            // 
            lblAccNum.AutoSize = true;
            lblAccNum.BackColor = Color.Transparent;
            lblAccNum.Font = new Font("Segoe UI Emoji", 14.25F, FontStyle.Bold);
            lblAccNum.ForeColor = Color.DarkSlateGray;
            lblAccNum.Location = new Point(599, 137);
            lblAccNum.Name = "lblAccNum";
            lblAccNum.Size = new Size(39, 26);
            lblAccNum.TabIndex = 22;
            lblAccNum.Text = "---";
            lblAccNum.Click += lblAccNum_Click;
            // 
            // depositSavingsrecepit
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(983, 386);
            Controls.Add(proceedBtn);
            Controls.Add(lblCurrentBalAdd);
            Controls.Add(lblAmountAdded);
            Controls.Add(lblAccNum);
            DoubleBuffered = true;
            FormBorderStyle = FormBorderStyle.None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "depositSavingsrecepit";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "depositSavingsrecepit";
            Load += depositSavingsrecepit_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Guna.UI2.WinForms.Guna2Button proceedBtn;
        private Label lblCurrentBalAdd;
        private Label lblAmountAdded;
        private Label lblAccNum;
    }
}